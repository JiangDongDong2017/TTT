#!/bin/sh
[ $# -ne 3 ] && {
 echo "Usage: sh 0105.sh <SU用户(SU或高权限用户)> <限制FTP访问权限的用户（若存在多个用户，输入格式如下：user1|user2|user3...若无请输入null）> <SU密码>";
 exit 1;
}

cdir=`pwd`

echo "touch /tmp/dassec_tmp;">/tmp/DAS{dastmp}_dassec_grub_tmp
echo "chmod 777 /tmp/dassec_tmp;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "if [ -f \"/etc/grub.conf\" ];then">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    grub_mod=\`ls -l /etc/grub.conf | grep 'l[r-][w-][x-]'\`;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    if [ -z \"\$grub_mod\" ];then">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "        grub_mod=\`ls -l /etc/grub.conf\`;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "        chmod --reference=/etc/grub.conf /tmp/dassec_tmp;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    else">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "        grub_mod=\`ls -l /boot/grub/grub.conf\`;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "        chmod --reference=/boot/grub/grub.conf /tmp/dassec_tmp;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    fi">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "elif [ -f \"/boot/grub/grub.conf\" ];then">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    grub_mod=\`ls -l /boot/grub/grub.conf\`;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    chmod --reference=/boot/grub/grub.conf /tmp/dassec_tmp;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "elif [ -f \"/etc/lilo.conf\" ];then">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    grub_mod=\`ls -l /etc/lilo.conf\`;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "    chmod --reference=/etc/lilo.conf /tmp/dassec_tmp;">>/tmp/DAS{dastmp}_dassec_grub_tmp
echo "fi">>/tmp/DAS{dastmp}_dassec_grub_tmp
sh /tmp/DAS{dastmp}_dassec_grub_tmp

# 执行pl脚本
perl $cdir/0105.pl "${1}" "${2}" "${3}"

#!env perl
my $para_num = "3";
my $tpl_tid="0105";
my %para;
@checkpoints = ();
@appendixes = ();

$para{Linux_su_user} = $ARGV[0];
$para{Linux_Ftp_User} = $ARGV[1];
$para{Linux_su_password} = $ARGV[2];

# 检查项/点

$cmd{1} = "chkconfig --list 2>/dev/null | grep \"^bootps\"";
$cmd{2} = "chkconfig --list 2>/dev/null | grep \"^tftp\"";
$cmd{3} = "chkconfig --list 2>/dev/null | grep \"^ident\"";
$cmd{4} = "chkconfig --list 2>/dev/null | grep \"^printer\"";
$cmd{5} = "chkconfig --list 2>/dev/null | grep \"^discard\"";
$cmd{6} = "chkconfig --list 2>/dev/null | grep \"^chargen\"";
$cmd{7} = "chkconfig --list 2>/dev/null | grep \"^sendmail\"";
$cmd{8} = "chkconfig --list 2>/dev/null | grep \"^ntalk\"";
$cmd{9} = "chkconfig --list 2>/dev/null | grep \"^nfs\"";
$cmd{10} = "chkconfig --list 2>/dev/null | grep \"^nfslock\"";
$cmd{11} = "chkconfig --list 2>/dev/null | grep \"^lpd\"";
$cmd{12} = "chkconfig --list 2>/dev/null | grep \"^kshell\"";
$cmd{13} = "chkconfig --list 2>/dev/null | grep \"^klogin\"";
$cmd{14} = "chkconfig --list 2>/dev/null | grep \"^ypbind\"";
$cmd{15} = "chkconfig --list 2>/dev/null | grep \"daytime\"";
$cmd{16} = "chkconfig --list 2>/dev/null | grep \"^time\"";
$cmd{17} = "chkconfig --list 2>/dev/null | grep \"^echo\"";
$cmd{18} = "if [ -a /etc/issue -o -a /etc/issue.net ];then echo \"issue file exist.result:false\";else echo \"issue file not exist.result:true\";fi";
$cmd{19} = "find / -maxdepth 3 -name .netrc 2>/dev/null";
$cmd{20} = "find / -maxdepth 3 -name .rhosts 2>/dev/null";
$cmd{21} = "find / -maxdepth 3 -name hosts.equiv 2>/dev/null";
$cmd{22} = "ls -al /etc/group";
$cmd{23} = "ls -al /etc/passwd";
$cmd{24} = "ls -al /etc/shadow";
$cmd{25} = "FTPSTATUS=`netstat -antp|grep -i \"listen\"|grep \":21\\>\"|wc -l`;
function Check_vsftpd(){ if [ -f /etc/vsftpd.conf ];then FTPCONF=\"/etc/vsftpd.conf\";elif [ -f /etc/vsftpd/vsftpd.conf ];then FTPCONF=\"/etc/vsftpd/vsftpd.conf\";else FTPCONF=\"null\";cat \$FTPCONF|egrep -v \"^[[:space:]]*#|^[[:space:]]*\$\";fi;if [ `grep -v \"^[[:space:]]*#\" \$FTPCONF|grep -i \"ftpd_banner\"|wc -l` != 0 ];then  echo \"vsftpd is running.Banner in \$FTPCONF is recommended.FTP check result:true\";else  echo \"vsftpd is running.Banner in \$FTPCONF is not recommended.FTP check result:false\";fi;unset FTPCONF; }
function Check_pureftpd(){ cat /etc/pure-ftpd/pure-ftpd.conf|egrep -v \"^[[:space:]]*#|^[[:space:]]*\$\";if [ `grep -v \"^[[:space:]]*#\" /etc/pure-ftpd/pure-ftpd.conf|grep -i \"FortunesFile\"|wc -l` == 0 ];then echo \"pure-ftpd is running.banner in pure-ftpd.conf is not recommended.FTP check result:false\";elif [ -s `grep -v \"^\$\" /etc/pure-ftpd/pure-ftpd.conf|grep -i fortunes|awk '{print \$2}'` ];then echo \"pure-ftpd is running.Banner in pure-ftpd.conf is recommended.FTP check result:true\";else echo \"pure-ftpd is running.Banner in pure-ftpd.conf is not recommended.FTP check result:false\";fi; }
if [ \$FTPSTATUS == 0 ];then  echo \"FTP is not running.FTP check result:true\";elif ([ `ps -ef|grep vsftpd|grep -v \"grep\"|wc -l` != 0 ]);then Check_vsftpd;elif ([ `ps -ef|grep pure-ftpd|grep -v \"grep\"|wc -l` != 0 ]);then Check_pureftpd;else echo \"vsftpd and pure-ftpd are not running,check result:true\";fi;unset FTPSTATUS;";
$cmd{26} = "ps -ef | grep -w \"sshd\" | grep -v grep";
$cmd{27} = "telnet_info=`rpm -qa |grep telnet`;if [ -z \"\$telnet_info\" ]; then echo disable = yes;else cat /etc/xinetd.d/telnet 2>/dev/null | grep disable || echo disable = yes;fi;";
$cmd{28} = "wu_status=`rpm -q wu-ftpd 2>/dev/null | grep \"^wu-ftpd\"`;
wu_status2=`netstat -antp|grep -i \"listen\"|grep -c \":21\\>\"`;
if [ -n \"\$wu_status\" ];then if [ -n \"\$wu_status2\" ];then if (cat /etc/passwd| grep \"^[[:space:]]*[^#]\" | grep \"^[[:space:]]*ftp\");then echo \"wu-ftp:invalid\";else \"wu-ftp:valid\";fi;else echo \"wu-ftpd:valid\";fi;else echo \"wu-ftpd:valid\";fi";
$cmd{29} = "if [ -s /etc/vsftpd.conf ];then ret=`cat /etc/vsftpd.conf | grep -v \"^[[:space:]]*#\" | grep \"anonymous_enable=NO\"`;elif [ -s /etc/vsftpd/vsftpd.conf ]; then ret=`cat /etc/vsftpd/vsftpd.conf | grep -v \"^[[:space:]]*#\" | grep \"anonymous_enable=NO\"`;else ret=\"result-true\";fi;if [ -n \"\$ret\" ];then echo \"result-true\";else echo \"result-false\";fi";
$cmd{30} = "if [ -s /etc/vsftpd/ftpusers ];then ret=`cat /etc/vsftpd/ftpusers | grep -v \"^[[:space:]]*#\" | grep \"\\broot\\b\"`;elif [ -s /etc/ftpusers ];then ret=`cat /etc/ftpusers | grep -v \"^[[:space:]]*#\" | grep \"\\broot\\b\"`;else ret=\"vsftpd valid\";fi;if [ -n \"\$ret\" ];then echo \"vsftpd valid\";else echo \"vsftpd invalid\";fi";
$cmd{31} = "wu_status=`rpm -q wu-ftpd 2>/dev/null | grep \"^wu-ftpd\"`;
wu_status2=`netstat -antp|grep -i \"listen\"|grep -c \":21\\>\"`;
if [ -n \"\$wu_status\" ];then if [ -n \"\$wu_status2\" ];then if (cat /etc/ftpusers 2>/dev/null | grep \"^[[:space:]]*[^#]\" | grep \"\\broot\\b\");then echo \"wu-ftp:valid\";else \"wu-ftp:invalid\";fi;else echo \"wu-ftpd:valid\";fi;else echo \"wu-ftpd:valid\";fi";
$cmd{32} = "unset red_ret red_ret2;
if [ -s /etc/syslog.conf ];then red_ret=`cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/rsyslog.conf ];then red_ret2=`cat /etc/rsyslog.conf | grep  -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -n \"\$red_ret\" ];then echo \"redhat:valid\";elif [ -n \"\$red_ret2\" ];then echo \"red-hat6:valid\";fi
unset red_ret red_ret2;
unset red_ret suse_ret suse_ret2 suse_ret3;
if [ -s /etc/syslog.conf ];then red_ret=`cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/rsyslog.conf ];then red_ret2=`cat /etc/rsyslog.conf | grep  -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then suse_ret=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"facility(authpriv)\" | grep \"filter\" | grep \"f_secure\" | awk '{print \$2}'`;if [ -n \"\$suse_ret\" ];then suse_ret2=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination\" | grep \"/var/log/secure\"`; if [ -n \"\$suse_ret2\" ];then suse_ret3=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"log\" | grep \"\$suse_ret\"`;fi;fi;fi
if [ -n \"\$red_ret\" ];then echo \"redhat-suse:valid\";elif [ -n \"\$red_ret2\" ];then echo \"red-hat6:valid\";elif [ -n \"\$suse_ret3\" ];then echo \"suse:valid\";else echo \"ret:no value\";fi;unset red_ret suse_ret suse_ret2 suse_ret3;";
$cmd{33} = "if [ -f /etc/syslog.conf ];then cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep -E '[[:space:]]*.+@.+';fi";
$cmd{34} = "if [ -s /etc/syslog-ng/syslog-ng.conf ];then ret_1=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"port(514)\"`;if [ -n \"\$ret_1\" ];then ret_2=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination(logserver)\"`;fi;fi
if [ -n \"\$ret_2\" ];then echo \"ret:set\";else echo \"ret:none\";fi";
$cmd{35} = "if [ -f /etc/rsyslog.conf ];then cat /etc/rsyslog.conf | grep -v \"^[[:space:]]*#\" | grep -E '[[:space:]]*.+@.+';fi";
$cmd{36} = "if [ -f /etc/rsyslog.conf ];then cat /etc/rsyslog.conf | grep -v \"^[[:space:]]*#\" | grep \"cron\\.\\*[[:space:]]*\" | grep \"/var/log/cron\";fi";
$cmd{37} = "if [ -f /etc/syslog.conf ];then cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"cron\\.\\*[[:space:]]*\" | grep \"/var/log/cron\";fi";
$cmd{38} = "if [ -s /etc/syslog-ng/syslog-ng.conf ];then a_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"filter[[:space:]]*f_cron[[:space:]]*{[[:space:]]*facility(cron);[[:space:]]*};\" | wc -l `;else a_i=1;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then b_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination[[:space:]]*cron[[:space:]]*{[[:space:]]*file(\\\"/var/log/cron\\\")[[:space:]]*;[[:space:]]*};\" | wc -l`;else b_i=1;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then c_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"log[[:space:]]*{[[:space:]]*source(src);[[:space:]]*filter(f_cron);[[:space:]]*destination(cron);[[:space:]]*};\" | wc -l`;else c_i=1;fi
if [[ \"\$a_i\" -ge 1 && \"\$b_i\" -ge 1 && \"\$c_i\" -ge 1 ]];then echo \"result:true\";else echo \"result:false\";fi";
$cmd{39} = "ls -al /var/log/cron";
$cmd{40} = "ls -al /var/log/spooler";
$cmd{41} = "ls -al /var/log/maillog";
$cmd{42} = "ls -al /var/log/mail";
$cmd{43} = "ls -al /var/log/secure";
$cmd{44} = "ls -al /var/log/messages";
$cmd{45} = "ls -al /var/log/boot.log";
$cmd{46} = "cat /etc/profile | grep -v \"^[[:space:]]*#\" |grep -i \"^[[:space:]]*umask\"";
$cmd{47} = "cat /etc/profile | grep -v \"^[[:space:]]*#\" | grep \"TMOUT[[:space:]]*=[[:space:]]*[0-9]*\" | grep -v \"export\" | sed 's/[^0-9]//g'
cat /etc/profile | grep -v \"^[[:space:]]*#\" | grep \"export[[:space:]]*TMOUT[[:space:]]*=[[:space:]]*[0-9]*\" | sed 's/[^0-9]//g'";
$cmd{48} = "cat /etc/ssh/sshd_config";
$cmd{49} = "cat /etc/pam.d/login 2>/dev/null | grep -v \"^[[:space:]]*#\" | grep \"^[[:space:]]*auth\"";
$cmd{50} = "file=\"/etc/login.defs\";if [ -s \${file} ];then ret=`cat \${file} | grep -v \"#\" | grep PASS_MAX_DAYS | awk -F ' ' '{print \$2}'`;fi
if [ 0 -ne \$ret  -a  90 -ge \$ret ];then echo \"PASS_MAX_DAYS ok\";else echo \"PASS_MAX_DAYS  fail\";fi";
$cmd{51} = "up_uidmin=`(grep -v ^# /etc/login.defs |grep \"^UID_MIN\"|awk '{print \$2}')`;
up_uidmax=`(grep -v ^# /etc/login.defs |grep \"^UID_MAX\"|awk '{print \$2}')`;
echo \"UIDMIN=\"\$up_uidmin;
echo \"UIDMAX=\"\$up_uidmax;
egrep -v \"oracle|sybase|postgres\" /etc/passwd | awk -F: '(\$3>='\$up_uidmin' && \$3<='\$up_uidmax') {print \$1\":\"\$3}';
echo \"result=\"`egrep -v \"oracle|sybase|postgres\" /etc/passwd|awk -F: '(\$3>='\$up_uidmin' && \$3<='\$up_uidmax') {print \$1\":\"\$3}'|wc -l`;unset up_uidmin up_uidmax";
$cmd{52} = "(cat /etc/pam.d/su | grep pam_rootok | grep \"^[[:space:]]*[^#]\";cat /etc/pam.d/su | grep pam_wheel.so | grep \"^[[:space:]]*[^#]\") | awk '{ORS=\",\"}{print \$0}'";
$cmd{53} = "cat /etc/login.defs";
$cmd{54} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd{55} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd{56} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"\\s*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"\\s*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"\\s*#\";fi";
$cmd{57} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd{58} = "awk -F: '{if(\$1==\"listen\"||\$1==\"gdm\"||\$1==\"webservd\"||\$1==\"nobody\"||\$1==\"nobody4\"||\$1==\"noaccess\"){if(\$2!=\"*\"&&\$2!~/!/)flag++}};END{if(flag==0)print \"ok\";else print \"no\"}' /etc/shadow";
$cmd{59} = "GID_MIN=`grep -v \"^[[:space:]]*#\" /etc/login.defs | grep \"^GID_MIN\" | awk '{print \$2}'`;GID_MAX=`grep -v \"^[[:space:]]*#\" /etc/login.defs | grep \"^GID_MAX\" | awk '{print \$2}'`;echo \"GID_MIN=\"\$GID_MIN;echo \"GID_MAX=\"\$GID_MAX;echo \"result:\"`egrep -v \"oracle|sybase|postgres\" /etc/passwd | awk -F: '(\$4<='\$GID_MAX' && \$4>='\$GID_MIN'){print \$4}' | wc -l`;";

push(@checkpoints, 1);
push(@checkpoints, 2);
push(@checkpoints, 3);
push(@checkpoints, 4);
push(@checkpoints, 5);
push(@checkpoints, 6);
push(@checkpoints, 7);
push(@checkpoints, 8);
push(@checkpoints, 9);
push(@checkpoints, 10);
push(@checkpoints, 11);
push(@checkpoints, 12);
push(@checkpoints, 13);
push(@checkpoints, 14);
push(@checkpoints, 15);
push(@checkpoints, 16);
push(@checkpoints, 17);
push(@checkpoints, 18);
push(@checkpoints, 19);
push(@checkpoints, 20);
push(@checkpoints, 21);
push(@checkpoints, 22);
push(@checkpoints, 23);
push(@checkpoints, 24);
push(@checkpoints, 25);
push(@checkpoints, 26);
push(@checkpoints, 27);
push(@checkpoints, 28);
push(@checkpoints, 29);
push(@checkpoints, 30);
push(@checkpoints, 31);
push(@checkpoints, 32);
push(@checkpoints, 33);
push(@checkpoints, 34);
push(@checkpoints, 35);
push(@checkpoints, 36);
push(@checkpoints, 37);
push(@checkpoints, 38);
push(@checkpoints, 39);
push(@checkpoints, 40);
push(@checkpoints, 41);
push(@checkpoints, 42);
push(@checkpoints, 43);
push(@checkpoints, 44);
push(@checkpoints, 45);
push(@checkpoints, 46);
push(@checkpoints, 47);
push(@checkpoints, 48);
push(@checkpoints, 49);
push(@checkpoints, 50);
push(@checkpoints, 51);
push(@checkpoints, 52);
push(@checkpoints, 53);
push(@checkpoints, 54);
push(@checkpoints, 55);
push(@checkpoints, 56);
push(@checkpoints, 57);
push(@checkpoints, 58);
push(@checkpoints, 59);

$cmd_sec{1} = "chkconfig --list 2>/dev/null | grep \"^bootps\"";
$cmd_sec{2} = "chkconfig --list 2>/dev/null | grep \"^tftp\"";
$cmd_sec{3} = "chkconfig --list 2>/dev/null | grep \"^ident\"";
$cmd_sec{4} = "chkconfig --list 2>/dev/null | grep \"^printer\"";
$cmd_sec{5} = "chkconfig --list 2>/dev/null | grep \"^discard\"";
$cmd_sec{6} = "chkconfig --list 2>/dev/null | grep \"^chargen\"";
$cmd_sec{7} = "chkconfig --list 2>/dev/null | grep \"^sendmail\"";
$cmd_sec{8} = "chkconfig --list 2>/dev/null | grep \"^ntalk\"";
$cmd_sec{9} = "chkconfig --list 2>/dev/null | grep \"^nfs\"";
$cmd_sec{10} = "chkconfig --list 2>/dev/null | grep \"^nfslock\"";
$cmd_sec{11} = "chkconfig --list 2>/dev/null | grep \"^lpd\"";
$cmd_sec{12} = "chkconfig --list 2>/dev/null | grep \"^kshell\"";
$cmd_sec{13} = "chkconfig --list 2>/dev/null | grep \"^klogin\"";
$cmd_sec{14} = "chkconfig --list 2>/dev/null | grep \"^ypbind\"";
$cmd_sec{15} = "chkconfig --list 2>/dev/null | grep \"daytime\"";
$cmd_sec{16} = "chkconfig --list 2>/dev/null | grep \"^time\"";
$cmd_sec{17} = "chkconfig --list 2>/dev/null | grep \"^echo\"";
$cmd_sec{18} = "if [ -a /etc/issue -o -a /etc/issue.net ];then echo \"issue file exist.result:false\";else echo \"issue file not exist.result:true\";fi";
$cmd_sec{19} = "find / -maxdepth 3 -name .netrc 2>/dev/null";
$cmd_sec{20} = "find / -maxdepth 3 -name .rhosts 2>/dev/null";
$cmd_sec{21} = "find / -maxdepth 3 -name hosts.equiv 2>/dev/null";
$cmd_sec{22} = "ls -al /etc/group";
$cmd_sec{23} = "ls -al /etc/passwd";
$cmd_sec{24} = "ls -al /etc/shadow";
$cmd_sec{25} = "FTPSTATUS=`netstat -antp|grep -i \"listen\"|grep \":21\\>\"|wc -l`;
function Check_vsftpd(){ if [ -f /etc/vsftpd.conf ];then FTPCONF=\"/etc/vsftpd.conf\";elif [ -f /etc/vsftpd/vsftpd.conf ];then FTPCONF=\"/etc/vsftpd/vsftpd.conf\";else FTPCONF=\"null\";cat \$FTPCONF|egrep -v \"^[[:space:]]*#|^[[:space:]]*\$\";fi;if [ `grep -v \"^[[:space:]]*#\" \$FTPCONF|grep -i \"ftpd_banner\"|wc -l` != 0 ];then  echo \"vsftpd is running.Banner in \$FTPCONF is recommended.FTP check result:true\";else  echo \"vsftpd is running.Banner in \$FTPCONF is not recommended.FTP check result:false\";fi;unset FTPCONF; }
function Check_pureftpd(){ cat /etc/pure-ftpd/pure-ftpd.conf|egrep -v \"^[[:space:]]*#|^[[:space:]]*\$\";if [ `grep -v \"^[[:space:]]*#\" /etc/pure-ftpd/pure-ftpd.conf|grep -i \"FortunesFile\"|wc -l` == 0 ];then echo \"pure-ftpd is running.banner in pure-ftpd.conf is not recommended.FTP check result:false\";elif [ -s `grep -v \"^\$\" /etc/pure-ftpd/pure-ftpd.conf|grep -i fortunes|awk '{print \$2}'` ];then echo \"pure-ftpd is running.Banner in pure-ftpd.conf is recommended.FTP check result:true\";else echo \"pure-ftpd is running.Banner in pure-ftpd.conf is not recommended.FTP check result:false\";fi; }
if [ \$FTPSTATUS == 0 ];then  echo \"FTP is not running.FTP check result:true\";elif ([ `ps -ef|grep vsftpd|grep -v \"grep\"|wc -l` != 0 ]);then Check_vsftpd;elif ([ `ps -ef|grep pure-ftpd|grep -v \"grep\"|wc -l` != 0 ]);then Check_pureftpd;else echo \"vsftpd and pure-ftpd are not running,check result:true\";fi;unset FTPSTATUS;";
$cmd_sec{26} = "ps -ef | grep -w \"sshd\" | grep -v grep";
$cmd_sec{27} = "telnet_info=`rpm -qa |grep telnet`;if [ -z \"\$telnet_info\" ]; then echo disable = yes;else cat /etc/xinetd.d/telnet 2>/dev/null | grep disable || echo disable = yes;fi;";
$cmd_sec{28} = "wu_status=`rpm -q wu-ftpd 2>/dev/null | grep \"^wu-ftpd\"`;
wu_status2=`netstat -antp|grep -i \"listen\"|grep -c \":21\\>\"`;
if [ -n \"\$wu_status\" ];then if [ -n \"\$wu_status2\" ];then if (cat /etc/passwd| grep \"^[[:space:]]*[^#]\" | grep \"^[[:space:]]*ftp\");then echo \"wu-ftp:invalid\";else \"wu-ftp:valid\";fi;else echo \"wu-ftpd:valid\";fi;else echo \"wu-ftpd:valid\";fi";
$cmd_sec{29} = "if [ -s /etc/vsftpd.conf ];then ret=`cat /etc/vsftpd.conf | grep -v \"^[[:space:]]*#\" | grep \"anonymous_enable=NO\"`;elif [ -s /etc/vsftpd/vsftpd.conf ]; then ret=`cat /etc/vsftpd/vsftpd.conf | grep -v \"^[[:space:]]*#\" | grep \"anonymous_enable=NO\"`;else ret=\"result-true\";fi;if [ -n \"\$ret\" ];then echo \"result-true\";else echo \"result-false\";fi";
$cmd_sec{30} = "if [ -s /etc/vsftpd/ftpusers ];then ret=`cat /etc/vsftpd/ftpusers | grep -v \"^[[:space:]]*#\" | grep \"\\broot\\b\"`;elif [ -s /etc/ftpusers ];then ret=`cat /etc/ftpusers | grep -v \"^[[:space:]]*#\" | grep \"\\broot\\b\"`;else ret=\"vsftpd valid\";fi;if [ -n \"\$ret\" ];then echo \"vsftpd valid\";else echo \"vsftpd invalid\";fi";
$cmd_sec{31} = "wu_status=`rpm -q wu-ftpd 2>/dev/null | grep \"^wu-ftpd\"`;
wu_status2=`netstat -antp|grep -i \"listen\"|grep -c \":21\\>\"`;
if [ -n \"\$wu_status\" ];then if [ -n \"\$wu_status2\" ];then if (cat /etc/ftpusers 2>/dev/null | grep \"^[[:space:]]*[^#]\" | grep \"\\broot\\b\");then echo \"wu-ftp:valid\";else \"wu-ftp:invalid\";fi;else echo \"wu-ftpd:valid\";fi;else echo \"wu-ftpd:valid\";fi";
$cmd_sec{32} = "unset red_ret red_ret2;
if [ -s /etc/syslog.conf ];then red_ret=`cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/rsyslog.conf ];then red_ret2=`cat /etc/rsyslog.conf | grep  -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -n \"\$red_ret\" ];then echo \"redhat:valid\";elif [ -n \"\$red_ret2\" ];then echo \"red-hat6:valid\";fi
unset red_ret red_ret2;
unset red_ret suse_ret suse_ret2 suse_ret3;
if [ -s /etc/syslog.conf ];then red_ret=`cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/rsyslog.conf ];then red_ret2=`cat /etc/rsyslog.conf | grep  -v \"^[[:space:]]*#\" | grep \"authpriv.\\*[[:space:]]*.*\"`;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then suse_ret=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"facility(authpriv)\" | grep \"filter\" | grep \"f_secure\" | awk '{print \$2}'`;if [ -n \"\$suse_ret\" ];then suse_ret2=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination\" | grep \"/var/log/secure\"`; if [ -n \"\$suse_ret2\" ];then suse_ret3=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"log\" | grep \"\$suse_ret\"`;fi;fi;fi
if [ -n \"\$red_ret\" ];then echo \"redhat-suse:valid\";elif [ -n \"\$red_ret2\" ];then echo \"red-hat6:valid\";elif [ -n \"\$suse_ret3\" ];then echo \"suse:valid\";else echo \"ret:no value\";fi;unset red_ret suse_ret suse_ret2 suse_ret3;";
$cmd_sec{33} = "if [ -f /etc/syslog.conf ];then cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep -E '[[:space:]]*.+@.+';fi";
$cmd_sec{34} = "if [ -s /etc/syslog-ng/syslog-ng.conf ];then ret_1=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"port(514)\"`;if [ -n \"\$ret_1\" ];then ret_2=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination(logserver)\"`;fi;fi
if [ -n \"\$ret_2\" ];then echo \"ret:set\";else echo \"ret:none\";fi";
$cmd_sec{35} = "if [ -f /etc/rsyslog.conf ];then cat /etc/rsyslog.conf | grep -v \"^[[:space:]]*#\" | grep -E '[[:space:]]*.+@.+';fi";
$cmd_sec{36} = "if [ -f /etc/rsyslog.conf ];then cat /etc/rsyslog.conf | grep -v \"^[[:space:]]*#\" | grep \"cron\\.\\*[[:space:]]*\" | grep \"/var/log/cron\";fi";
$cmd_sec{37} = "if [ -f /etc/syslog.conf ];then cat /etc/syslog.conf | grep -v \"^[[:space:]]*#\" | grep \"cron\\.\\*[[:space:]]*\" | grep \"/var/log/cron\";fi";
$cmd_sec{38} = "if [ -s /etc/syslog-ng/syslog-ng.conf ];then a_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"filter[[:space:]]*f_cron[[:space:]]*{[[:space:]]*facility(cron);[[:space:]]*};\" | wc -l `;else a_i=1;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then b_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"destination[[:space:]]*cron[[:space:]]*{[[:space:]]*file(\\\"/var/log/cron\\\")[[:space:]]*;[[:space:]]*};\" | wc -l`;else b_i=1;fi
if [ -s /etc/syslog-ng/syslog-ng.conf ];then c_i=`cat /etc/syslog-ng/syslog-ng.conf | grep -v \"^[[:space:]]*#\" | grep \"log[[:space:]]*{[[:space:]]*source(src);[[:space:]]*filter(f_cron);[[:space:]]*destination(cron);[[:space:]]*};\" | wc -l`;else c_i=1;fi
if [[ \"\$a_i\" -ge 1 && \"\$b_i\" -ge 1 && \"\$c_i\" -ge 1 ]];then echo \"result:true\";else echo \"result:false\";fi";
$cmd_sec{39} = "ls -al /var/log/cron";
$cmd_sec{40} = "ls -al /var/log/spooler";
$cmd_sec{41} = "ls -al /var/log/maillog";
$cmd_sec{42} = "ls -al /var/log/mail";
$cmd_sec{43} = "ls -al /var/log/secure";
$cmd_sec{44} = "ls -al /var/log/messages";
$cmd_sec{45} = "ls -al /var/log/boot.log";
$cmd_sec{46} = "cat /etc/profile | grep -v \"^[[:space:]]*#\" |grep -i \"^[[:space:]]*umask\"";
$cmd_sec{47} = "cat /etc/profile | grep -v \"^[[:space:]]*#\" | grep \"TMOUT[[:space:]]*=[[:space:]]*[0-9]*\" | grep -v \"export\" | sed 's/[^0-9]//g'
cat /etc/profile | grep -v \"^[[:space:]]*#\" | grep \"export[[:space:]]*TMOUT[[:space:]]*=[[:space:]]*[0-9]*\" | sed 's/[^0-9]//g'";
$cmd_sec{48} = "cat /etc/ssh/sshd_config";
$cmd_sec{49} = "cat /etc/pam.d/login 2>/dev/null | grep -v \"^[[:space:]]*#\" | grep \"^[[:space:]]*auth\"";
$cmd_sec{50} = "file=\"/etc/login.defs\";if [ -s \${file} ];then ret=`cat \${file} | grep -v \"#\" | grep PASS_MAX_DAYS | awk -F ' ' '{print \$2}'`;fi
if [ 0 -ne \$ret  -a  90 -ge \$ret ];then echo \"PASS_MAX_DAYS ok\";else echo \"PASS_MAX_DAYS  fail\";fi";
$cmd_sec{51} = "up_uidmin=`(grep -v ^# /etc/login.defs |grep \"^UID_MIN\"|awk '{print \$2}')`;
up_uidmax=`(grep -v ^# /etc/login.defs |grep \"^UID_MAX\"|awk '{print \$2}')`;
echo \"UIDMIN=\"\$up_uidmin;
echo \"UIDMAX=\"\$up_uidmax;
egrep -v \"oracle|sybase|postgres\" /etc/passwd | awk -F: '(\$3>='\$up_uidmin' && \$3<='\$up_uidmax') {print \$1\":\"\$3}';
echo \"result=\"`egrep -v \"oracle|sybase|postgres\" /etc/passwd|awk -F: '(\$3>='\$up_uidmin' && \$3<='\$up_uidmax') {print \$1\":\"\$3}'|wc -l`;unset up_uidmin up_uidmax";
$cmd_sec{52} = "(cat /etc/pam.d/su | grep pam_rootok | grep \"^[[:space:]]*[^#]\";cat /etc/pam.d/su | grep pam_wheel.so | grep \"^[[:space:]]*[^#]\") | awk '{ORS=\",\"}{print \$0}'";
$cmd_sec{53} = "cat /etc/login.defs";
$cmd_sec{54} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd_sec{55} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd_sec{56} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"\\s*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"\\s*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"\\s*#\";fi";
$cmd_sec{57} = "if [ -s /etc/pam.d/system-auth ];then cat /etc/pam.d/system-auth|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/common-password ];then cat /etc/pam.d/common-password|grep -v \"^[[:space:]]*#\";elif [ -s /etc/pam.d/passwd ];then cat /etc/pam.d/passwd | grep -v \"^[[:space:]]*#\";fi";
$cmd_sec{58} = "awk -F: '{if(\$1==\"listen\"||\$1==\"gdm\"||\$1==\"webservd\"||\$1==\"nobody\"||\$1==\"nobody4\"||\$1==\"noaccess\"){if(\$2!=\"*\"&&\$2!~/!/)flag++}};END{if(flag==0)print \"ok\";else print \"no\"}' /etc/shadow";
$cmd_sec{59} = "GID_MIN=`grep -v \"^[[:space:]]*#\" /etc/login.defs | grep \"^GID_MIN\" | awk '{print \$2}'`;GID_MAX=`grep -v \"^[[:space:]]*#\" /etc/login.defs | grep \"^GID_MAX\" | awk '{print \$2}'`;echo \"GID_MIN=\"\$GID_MIN;echo \"GID_MAX=\"\$GID_MAX;echo \"result:\"`egrep -v \"oracle|sybase|postgres\" /etc/passwd | awk -F: '(\$4<='\$GID_MAX' && \$4>='\$GID_MIN'){print \$4}' | wc -l`;";

# 附录检查项

$appendix_cmd{1} = "cat /etc/vsftpd/chroot_list 2>/dev/null | grep \"^[[:space:]]*[^#]\" | head -300";
$appendix_cmd{2} = "rm -fv /tmp/DAS{dastmp}_dassec_grub_tmp";

push(@appendixes, 1);
push(@appendixes, 2);

$appendix_cmd_sec{1} = "cat /etc/vsftpd/chroot_list 2>/dev/null | grep \"^[[:space:]]*[^#]\" | head -300";
$appendix_cmd_sec{2} = "rm -fv /tmp/DAS{dastmp}_dassec_grub_tmp";

 # 生成结果文件
sub add_point{
 my ($str, $flag, $command, $value, $tpl_tid)= @_;
 $str .= "    ".'<ck_'.$tpl_tid.'_'.'common_'.$flag.'>'."\n";
 $str .= "      ".'<cmd><![CDATA['.$command."]]></cmd>\n";
 $str .= "      <value><![CDATA[".$value."]]></value>\n";
 $str .= "    ".'</ck_'.$tpl_tid.'_'.'common_'.$flag.'>'."\n";
 return $str;}
sub add_appendix{
 my ($str, $flag, $command, $value, $tpl_tid)= @_;
 $str .= "    ".'<ck_'.$tpl_tid.'_'.'info_'.$flag.'>'."\n";
 $str .= "      ".'<cmd><![CDATA['.$command."]]></cmd>\n";
 $str .= "      <value><![CDATA[".$value."]]></value>\n";
 $str .= "    ".'</ck_'.$tpl_tid.'_'.'info_'.$flag.'>'."\n";
 return $str;}
 sub generate_xml{
 $ARGC = @ARGV;
if($ARGC lt 3){
 print qq{usag: 0105.pl <SU用户(SU或高权限用户)> <限制FTP访问权限的用户（若存在多个用户，输入格式如下：user1|user2|user3...若无请输入null）> <SU密码>};
exit;}
 my $date = `date +%Y-%m-%d`;
 chomp $date;
my $ipaddr = "";
my $ipaddr = `ifconfig | grep -oE 'inet[[:space:]]*(addr)?\.?([0-9]{1,3}\.?){4}' | grep -v 127 | grep -oE '([0-9]{1,3}\.?){4}' | head -n 1`;
chomp $ipaddr;
$ipaddr =~ s/^\s+|\s+$//g;
 my $xml_str = "";
 $xml_str .='<?xml version="1.0" encoding="UTF-8"?>'."\n";
 $xml_str .= '<root tid= "'.'0105'.'" level="'.''.'" ip="'.$ipaddr.'" time="'.$date.'">'."\n";
 $xml_str .= '<ck_'.$tpl_tid.'_init_0>'."
<cmd><![CDATA[]]></cmd>
"."<value><![CDATA[]]></value>
".'</ck_'.$tpl_tid.'_init_0>'."
";
 foreach $key (@checkpoints){
 $value = $cmd{$key};
 $value_sec = $cmd_sec{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_str = &add_point( $xml_str, $key, $value_sec, $tmp_result, $tpl_tid );}  
 foreach $key (@appendixes){
 $value = $appendix_cmd{$key};
 $value_sec = $appendix_cmd_sec{$key};
 my $tmp_result = `$value`;
 chomp $tmp_result;
 $tmp_result =~ s/>/&gt;/g;
 $xml_str = &add_appendix( $xml_str, $key, $value_sec, $tmp_result, $tpl_tid );}
 $xml_str .= "</root>"."\n";
 $xmlfile = $ipaddr."_"."0105"."_chk.xml";
 print $xmlfile."\n";
 open XML,">/tmp/".$xmlfile or die "Cannot create ip.xml:$!";
 print XML $xml_str;
 print "end write xml\n";
 print "OK\n";}
 generate_xml();
